# Fundi Plan Awareness

Fundi will contextually adapt to user tier:
- During Trial:
  - Encouragement & onboarding suggestions
  - Reminders about premium trial expiration
- On Free Plan:
  - Nudges when limits are hit
  - Hints about locked features
- On Paid Plans:
  - Personalized recommendations unlocked
  - Encouragement to explore unused features