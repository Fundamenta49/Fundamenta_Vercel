# API Cost Controls

- Feature gating during trial
- Gradual access to resource-heavy APIs
- Monthly usage caps per tier
- Highlight high-retention, low-cost features
- Fundi alerting when nearing usage limits