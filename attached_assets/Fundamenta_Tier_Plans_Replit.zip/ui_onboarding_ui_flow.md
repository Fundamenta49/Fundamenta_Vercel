# Onboarding UI Flow (3-Day Trial)

1. Welcome Modal
2. Fundi Avatar Intro
3. Goal-setting form
4. Personalized Path Quiz
5. Feature Highlights Carousel
6. Final CTA (Day 3)