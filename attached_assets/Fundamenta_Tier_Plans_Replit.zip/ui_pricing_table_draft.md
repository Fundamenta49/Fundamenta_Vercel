# Pricing Table Draft

| Plan | Price | Learning Paths | Journals | Fitness | Documents | Support |
|------|-------|----------------|----------|---------|-----------|---------|
| Essentials | Free | 2 | 5 | Basic | - | Community |
| Personal Growth | $5.99 | 5 | 30 | Enhanced | 3/mo | Email |
| Life Navigator | $12.99 | Unlimited | 100 | Custom | 10/mo | Priority |
| Complete | $24.99 | Unlimited | Unlimited | Custom + Coaching | Unlimited | 1:1 Quarterly |